SELECT * FROM sale.amazon;

-- 2.1 -- Add a new column named timeofday to give insight of sales in the Morning, Afternoon, Evening
-- This will help answer the question on which part of the day most sales are made.alter

alter table sale.amazon add column Timeofday varchar(20)

update sale.amazon
set Timeofday = case
when hour(Time) < 12 Then "Morning"
when hour (Time) < 17 Then "Afternoon"
else "Evening"
end;
 
 --2.2-- Add a new column named dayname that contains the extracted day of the week on which the given Transaction took place (Mon, Tue, Wed, Thur, Fri)
 -- This will help answer the question on which week of the day each branch is busiest.
 
 alter table sale.amazon add column dayname varchar(20);
 
 update sale.amazon
 set dayname = dayname(date);
 
 -- 2.3-- Add a new column named monthname that contains the extracted months of the year on which given transaction took place (Jan, Feb, Mar)
 -- This will help determine which month of the year has the most sale and profit.
 
 alter table sale.amazon add column monthname varchar(20);
 
 update sale.amazon
 set monthname = monthname(date);
 
 select * from sale.amazon
 
 -- Ques 1: What is the count of distinct cities in the dataset?
 
select count(distinct city) from sale.amazon;

-- Ques 2: For each branch, What is the corresponding city?

select distinct city, branch from sale.amazon 

-- Ques 3: What is the count of distinct product lines in the dataset?

select COUNT(distinct `Product line`)  from sale.amazon;
 
 -- Ques 4: Which payment method occures most frequently?
 
 select payment, count(payment) from sale.amazon
 group by payment;
 
 -- Ques 5: Which product line has the highest sales?
 
 select `product line` , count(*) as maxprodline from sale.amazon
 group by `product line`
 order by maxprodline desc
 limit 1;
 
 -- Ques 6: How much revenue is generated each month?
 
 select monthname, sum(Total) as Revenue
 from sale.amazon
 group by monthname;
 
 -- Ques 7: In which month did the cost of goods sold reach its peak?
 
 select monthname, max(cogs) as max_cogs
 from sale.amazon
 group by monthname
 order by max_cogs desc
 limit 1;
 
 -- Ques 8: Which product line generated the highest revenue?
 
 select max(`product line`) as Highest_revenue from sale.amazon;
 
 -- Ques 9: in Which city was the highest revenue recorded?
 
 select city , sum(`gross income`) as highest_revenue_recorded 
 from sale.amazon
 group by city
 order by highest_revenue_recorded desc
 limit 1;
 
 -- Ques 10: Which product line incurred the highest Value Added Tax?
 select * from sale.amazon;
 select `product line`, sum(`Tax 5%`) as highest_tax
 from sale.amazon
 group by `product line`
 order by highest_tax desc
 limit 1;
 
 -- Ques 11: For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad".
 

        
-- Ques 12:  Identify the branch that exceeded the average number of products sold

select branch , sum(Quantity) as prod_sold
from sale.amazon
group by branch
having prod_sold > (select avg(Quantity) from sale.amazon);

-- Ques 13: Which product line is most frequently associated with each gender?

select gender, `product line`, count(gender) as total_count
from sale.amazon
group by gender ,`Product line`
order by total_count desc;

-- Ques 14: Calculate the average rating for each product line?
select * from sale.amazon;
select `product line`, round(avg(rating),2) as avg_rating
from sale.amazon
group by `product line`
order by avg_rating desc;

-- Ques 15: Count the sales occurences for each time of day on every weekday?
select * from sale.amazon;
select timeofday , count(*) as total_sales
from sale.amazon
where dayname BETWEEN  "Monday" and "Sunday"
group by timeofday
order by total_sales desc

-- Ques 16: Identify the customer type contributing the highest revenue?

select `customer type`, sum(total) as total_revenue
from sale.amazon
group by `customer type`
order by total_revenue desc;

-- Ques 17: Determine the city with the highest VAT percentage?

select city , sum(`Tax 5%`) as total_vat
from sale.amazon
group by city
order by total_vat desc;

-- Ques 18: Identify the customer type with the highest VAT payments.

select `customer type` , avg(`Tax 5%`) as vat
from sale.amazon
group by `customer type`
order by vat desc
limit 1;

-- Ques 19: What is the count of distinct customer types in the dataset?

select count(distinct `customer type`) from sale.amazon;

-- Ques 20: What is the count of distinct payment methods in the dataset?

select count(distinct payment) from sale.amazon;

-- Ques 21: Which customer type occurs most frequently?

select `customer type` , count(*) as total_sales
from sale.amazon
group by `customer type`
order by total_sales desc
limit 1;

-- Ques 22: Identify the customer type with the highest purchase frequency.

select * from sale.amazon;

select `customer type` , count(*) as total_sales
from sale.amazon
group by `customer type`
order by total_sales desc
limit 1; 

-- Ques 23: Determine the predominant gender among customers.

select  max(Gender) as Predominant_gender from sale.amazon;

-- Ques 24: Examine the distribution of genders within each branch.

select gender ,count(*) as gender_count
from sale.amazon
where branch = "C"
group by gender
order by gender_count desc;

-- Ques 25: Identify the time of day when customers provide the most ratings.

select timeofday , count(rating) as total_rate
from sale.amazon
group by timeofday
order by total_rate desc; 

-- Ques 26: Determine the time of day with the highest customer ratings for each branch.

select timeofday , avg(rating) as avg_rating
from sale.amazon
where branch = "B"
group by timeofday
order by avg_rating desc;

-- Ques 27: Identify the day of the week with the highest average ratings.

select dayname , avg(rating) as avg_rating
from sale.amazon
group by dayname
order by avg_rating desc;

-- Ques 28: Determine the day of the week with the highest average ratings for each branch.

select dayname, avg(rating) as avg_rating
from sale.amazon
where branch = "A"
group by dayname
order by avg_rating desc;











 
 